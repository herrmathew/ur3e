#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from geometry_msgs.msg import WrenchStamped
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from sensor_msgs.msg import JointState
import numpy as np
from copy import deepcopy

class AdmittanceController(Node):
    def __init__(self):
        super().__init__('admittance_controller')
        
        # Parameters
        self.declare_parameters(
            namespace='',
            parameters=[
                ('mass_matrix', [1.0, 1.0, 1.0, 0.5, 0.5, 0.5]),  # Virtual mass for x,y,z, rx,ry,rz
                ('damping_matrix', [50.0, 50.0, 50.0, 5.0, 5.0, 5.0]),  # Damping for x,y,z, rx,ry,rz
                ('force_deadband', 2.0),  # Forces below this value (N) are ignored
                ('torque_deadband', 0.1),  # Torques below this value (Nm) are ignored
                ('max_velocity', 0.1),  # Maximum allowed velocity (m/s)
                ('update_rate', 100.0),  # Controller update rate in Hz
            ]
        )
        
        # Get parameters
        self.mass_matrix = np.diag(self.get_parameter('mass_matrix').value)
        self.damping_matrix = np.diag(self.get_parameter('damping_matrix').value)
        self.force_deadband = self.get_parameter('force_deadband').value
        self.torque_deadband = self.get_parameter('torque_deadband').value
        self.max_velocity = self.get_parameter('max_velocity').value
        update_rate = self.get_parameter('update_rate').value
        
        # QoS profile for better reliability
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        # Subscribers
        self.wrench_sub = self.create_subscription(
            WrenchStamped,
            'wrench',
            self.wrench_callback,
            qos_profile
        )
        
        self.joint_state_sub = self.create_subscription(
            JointState,
            'joint_states',
            self.joint_state_callback,
            qos_profile
        )
        
        # Action client for trajectory execution
        self.trajectory_client = ActionClient(
            self, 
            FollowJointTrajectory, 
            'joint_trajectory_controller/follow_joint_trajectory'
        )
        
        # Initialize variables
        self.current_wrench = np.zeros(6)  # [fx, fy, fz, tx, ty, tz]
        self.current_velocity = np.zeros(6)  # [vx, vy, vz, wx, wy, wz]
        self.current_joints = None
        self.joint_names = ['shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint',
                          'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint']
        
        # Create timer for the control loop
        self.timer = self.create_timer(1.0/update_rate, self.control_loop)
        
        self.get_logger().info('Admittance Controller initialized')

    def wrench_callback(self, msg):
        # Apply deadband and update current wrench
        force = np.array([msg.wrench.force.x, msg.wrench.force.y, msg.wrench.force.z])
        torque = np.array([msg.wrench.torque.x, msg.wrench.torque.y, msg.wrench.torque.z])
        
        # Apply deadband
        force[abs(force) < self.force_deadband] = 0.0
        torque[abs(torque) < self.torque_deadband] = 0.0
        
        self.current_wrench = np.concatenate([force, torque])

    def joint_state_callback(self, msg):
        # Store current joint positions
        if not self.current_joints:
            # Initialize joint positions on first callback
            self.current_joints = {}
            for name, position in zip(msg.name, msg.position):
                if name in self.joint_names:
                    self.current_joints[name] = position
        else:
            # Update joint positions
            for name, position in zip(msg.name, msg.position):
                if name in self.joint_names:
                    self.current_joints[name] = position

    def control_loop(self):
        if not self.current_joints:
            return

        # Admittance control law
        # M*dv/dt + D*v = F
        # Using simple Euler integration
        dt = 1.0/self.get_parameter('update_rate').value
        
        # Calculate new velocity using admittance law
        accel = np.linalg.inv(self.mass_matrix) @ (self.current_wrench - 
                self.damping_matrix @ self.current_velocity)
        new_velocity = self.current_velocity + accel * dt
        
        # Apply velocity limits
        velocity_norm = np.linalg.norm(new_velocity[:3])  # Only consider linear velocity
        if velocity_norm > self.max_velocity:
            new_velocity[:3] *= self.max_velocity / velocity_norm
        
        self.current_velocity = new_velocity
        
        # Calculate new position
        delta_pos = self.current_velocity * dt
        
        # Create trajectory message
        traj = JointTrajectory()
        traj.joint_names = self.joint_names
        
        # Current point
        current_point = JointTrajectoryPoint()
        current_point.positions = [self.current_joints[name] for name in self.joint_names]
        current_point.time_from_start.sec = 0
        
        # Target point (simple differential kinematic control)
        target_point = JointTrajectoryPoint()
        # Here you would need to convert delta_pos to joint velocities using the Jacobian
        # For simplicity, we're just adding a small movement in joint space
        # In a real implementation, you would use the robot's Jacobian to convert
        # Cartesian velocities to joint velocities
        target_point.positions = [pos + vel * dt for pos, vel in 
                                zip(current_point.positions, [0.01, 0.01, 0.01, 0.01, 0.01, 0.01])]
        target_point.time_from_start.sec = 1
        
        traj.points = [current_point, target_point]
        
        # Create and send goal
        goal_msg = FollowJointTrajectory.Goal()
        goal_msg.trajectory = traj
        
        self.trajectory_client.wait_for_server()
        self.trajectory_client.send_goal_async(goal_msg)

def main(args=None):
    rclpy.init(args=args)
    controller = AdmittanceController()
    try:
        rclpy.spin(controller)
    except KeyboardInterrupt:
        pass
    finally:
        controller.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
