from setuptools import setup

package_name = 'ur_sim'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/config',
            ['config/ur3e_controllers_gripper.yaml',
             'config/ur3e_admittance_controller.yaml']),
        ('share/' + package_name + '/urdf',
            ['urdf/ur3e_spawn_gripper.urdf.xacro',
             'urdf/robotiq_gripper_macro.xacro']),
        ('share/' + package_name + '/launch',
            ['launch/ur3e_cartesian_control.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='admin-dev',
    maintainer_email='your.email@example.com',
    description='UR3e with Robotiq gripper simulation and control',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'admittance_controller = ur_sim.admittance_controller:main',
        ],
    },
)
